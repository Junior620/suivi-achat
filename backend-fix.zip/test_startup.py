#!/usr/bin/env python3
"""Test script to diagnose startup issues"""
import sys
import os

print("=" * 50)
print("STARTUP DIAGNOSTIC TEST")
print("=" * 50)

# Test 1: Python version
print(f"\n1. Python version: {sys.version}")

# Test 2: Environment variables
print("\n2. Environment variables:")
print(f"   DATABASE_URL: {os.getenv('DATABASE_URL', 'NOT SET')[:50]}...")
print(f"   JWT_SECRET: {'SET' if os.getenv('JWT_SECRET') else 'NOT SET'}")
print(f"   SECRET_KEY: {'SET' if os.getenv('SECRET_KEY') else 'NOT SET'}")

# Test 3: Import app modules
print("\n3. Testing imports...")
try:
    from app.config import settings
    print("   ✓ app.config imported")
except Exception as e:
    print(f"   ✗ app.config failed: {e}")
    sys.exit(1)

try:
    from app.database import engine
    print("   ✓ app.database imported")
except Exception as e:
    print(f"   ✗ app.database failed: {e}")
    sys.exit(1)

# Test 4: Database connection
print("\n4. Testing database connection...")
try:
    with engine.connect() as conn:
        result = conn.execute("SELECT 1")
        print("   ✓ Database connection successful")
except Exception as e:
    print(f"   ✗ Database connection failed: {e}")
    sys.exit(1)

# Test 5: Import main app
print("\n5. Testing main app import...")
try:
    from app.main import app
    print("   ✓ app.main imported successfully")
except Exception as e:
    print(f"   ✗ app.main failed: {e}")
    import traceback
    traceback.print_exc()
    sys.exit(1)

print("\n" + "=" * 50)
print("ALL TESTS PASSED ✓")
print("=" * 50)
