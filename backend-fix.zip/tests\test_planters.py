"""Tests des planteurs"""
import pytest

def test_create_planter(client, auth_headers):
    """Test création d'un planteur"""
    response = client.post("/api/v1/planters", headers=auth_headers, json={
        "name": "Jean Dupont",
        "phone": "+237600000001",
        "location": "Yaoundé",
        "code": "PL001"
    })
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Jean Dupont"
    assert data["phone"] == "+237600000001"

def test_get_planters(client, auth_headers):
    """Test récupération liste planteurs"""
    # Créer quelques planteurs
    for i in range(3):
        client.post("/api/v1/planters", headers=auth_headers, json={
            "name": f"Planteur {i}",
            "phone": f"+23760000000{i}",
            "location": "Douala",
            "code": f"PL00{i}"
        })
    
    response = client.get("/api/v1/planters", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert len(data) >= 3

def test_get_planter_by_id(client, auth_headers):
    """Test récupération d'un planteur par ID"""
    # Créer un planteur
    create_response = client.post("/api/v1/planters", headers=auth_headers, json={
        "name": "Test Planter",
        "phone": "+237600000099",
        "location": "Bafoussam",
        "code": "PL099"
    })
    planter_id = create_response.json()["id"]
    
    # Récupérer par ID
    response = client.get(f"/api/v1/planters/{planter_id}", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Test Planter"

def test_update_planter(client, auth_headers):
    """Test mise à jour d'un planteur"""
    # Créer
    create_response = client.post("/api/v1/planters", headers=auth_headers, json={
        "name": "Original Name",
        "phone": "+237600000088",
        "location": "Kribi",
        "code": "PL088"
    })
    planter_id = create_response.json()["id"]
    
    # Mettre à jour
    response = client.put(f"/api/v1/planters/{planter_id}", headers=auth_headers, json={
        "name": "Updated Name",
        "phone": "+237600000088",
        "location": "Kribi"
    })
    assert response.status_code == 200
    data = response.json()
    assert data["name"] == "Updated Name"

def test_delete_planter(client, auth_headers):
    """Test suppression d'un planteur"""
    # Créer
    create_response = client.post("/api/v1/planters", headers=auth_headers, json={
        "name": "To Delete",
        "phone": "+237600000077",
        "location": "Limbe",
        "code": "PL077"
    })
    planter_id = create_response.json()["id"]
    
    # Supprimer
    response = client.delete(f"/api/v1/planters/{planter_id}", headers=auth_headers)
    assert response.status_code == 200
    
    # Vérifier suppression
    get_response = client.get(f"/api/v1/planters/{planter_id}", headers=auth_headers)
    assert get_response.status_code == 404
