"""Tests des factures"""
import pytest
from datetime import date, timedelta

def test_create_invoice(client, auth_headers):
    """Test création d'une facture"""
    # Créer un planteur d'abord
    planter_response = client.post("/api/v1/planters", headers=auth_headers, json={
        "name": "Invoice Test Planter",
        "phone": "+237600000055",
        "location": "Douala",
        "code": "PL055"
    })
    planter_id = planter_response.json()["id"]
    
    # Créer une facture
    response = client.post("/api/v1/invoices", headers=auth_headers, json={
        "planter_id": planter_id,
        "amount_ht": 1000000,
        "tva_rate": 18,
        "issue_date": date.today().isoformat(),
        "due_date": (date.today() + timedelta(days=30)).isoformat(),
        "notes": "Test invoice"
    })
    assert response.status_code == 200
    data = response.json()
    assert "invoice_number" in data
    assert data["amount_ht"] == 1000000
    assert data["tva_rate"] == 18
    assert data["amount_ttc"] == 1180000

def test_get_invoices(client, auth_headers):
    """Test récupération liste factures"""
    response = client.get("/api/v1/invoices", headers=auth_headers)
    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)

def test_invoice_status_update(client, auth_headers):
    """Test changement de statut d'une facture"""
    # Créer planteur et facture
    planter_response = client.post("/api/v1/planters", headers=auth_headers, json={
        "name": "Status Test Planter",
        "phone": "+237600000044",
        "location": "Yaoundé",
        "code": "PL044"
    })
    planter_id = planter_response.json()["id"]
    
    invoice_response = client.post("/api/v1/invoices", headers=auth_headers, json={
        "planter_id": planter_id,
        "amount_ht": 500000,
        "tva_rate": 18,
        "issue_date": date.today().isoformat()
    })
    invoice_id = invoice_response.json()["id"]
    
    # Changer le statut
    response = client.put(f"/api/v1/invoices/{invoice_id}/status", 
                         headers=auth_headers, 
                         json={"status": "paid"})
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "paid"
